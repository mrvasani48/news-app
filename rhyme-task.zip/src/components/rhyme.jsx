import axios from 'axios';
import React, { useState } from 'react'

export default function Rhyme() {

    const [inputSearch,setIsearch]=useState();
    const[rhymeData,setrhymeData]=useState();
    const url = `https://api.datamuse.com/words?rel_rhy=${inputSearch}`;

    function loadData (){
      axios.get(url)
      .then((responce)=>{ 
         setrhymeData(responce?.data)
      })
      .catch((error)=>{
        console.log(error);
      })
  }
  return (
    <div className='main-wrapper'> 
    <div >
       <h1 className='head'>Rhyme App</h1>
       <label htmlFor='rhyme'>Rhyme word : </label>
       <input id='rhyme' type="text" onChange={(e)=>setIsearch(e.target.value)} ></input>
       <div>
       <button className='btn' onClick={loadData}>Search</button>
       </div>
       
    </div>
    <div>
        {rhymeData?.map((value,index)=>(
               <div key={index}>
                 <h3> rhyme word : {value.word}</h3>
              </div>
           ))}   
     </div>
      </div>
  )
}
