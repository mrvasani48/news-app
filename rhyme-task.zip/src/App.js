import './App.css';
import Rhyme from './components/rhyme'
function App() {
  return (
       <Rhyme />
  );
} 
export default App;
