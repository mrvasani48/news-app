import React  from "react";
import "./calculator.css"
class Calculator extends React.Component
{  
    state= {
        result:""
    }
    onclickhandeler =(event)=>{  
    if(event.target.value ==="="){
        this.calculate();
       }   
    else if(event.target.value ==="C"){
        this.clearval();
       }
    else if(event.target.value ==="CE"){
        this.backspace();
       }
    else{
        this.setState({ result:  this.state.result + event.target.value})
       }
    }
    calculate =()=>{ 

    try{
        this.setState({ result: eval( this.state.result) }) 
        }
    catch (e){
        this.setState({
                result: "Error"
            })
        }
    } 
    clearval =()=>{
        this.setState({ result: " "  })   
    } 
    backspace =()=>{
        this.setState({ result: this.state.result.slice(0,-1) })
    }
    render(){
        return(
            <div className="main">
              <h1 className="heading">Simple Calculator </h1>
              <p className="result"> {this.state.result}</p>
              <div className="buttons">
              <div >
                   <button className="button"  value={'('} onClick={this.onclickhandeler}>(</button>
                   <button className="button"  value={'CE'} onClick={this.onclickhandeler} >CE</button>
                   <button className="button"  value={')'} onClick={this.onclickhandeler}>)</button>
                   <button className="button"  value={'C'} onClick={this.onclickhandeler}>C</button>
              </div>
              <div>
                   <button className="button"  value={7} onClick={this.onclickhandeler} >7</button>
                   <button className="button"  value={8} onClick={this.onclickhandeler}>8</button>
                   <button className="button"  value={9} onClick={this.onclickhandeler}>9 </button>
                   <button className="button"  value={'+'} onClick={this.onclickhandeler}>+</button>
              </div>
              <div>
                   <button className="button"  value={4} onClick={this.onclickhandeler}>4</button>
                   <button className="button"  value={5} onClick={this.onclickhandeler}>5</button>
                   <button className="button"  value={6} onClick={this.onclickhandeler}>6</button>
                   <button className="button"  value={'-'} onClick={this.onclickhandeler}>-</button>
              </div>
              <div>
                    <button className="button"  value={1}   onClick={this.onclickhandeler}>1</button>
                    <button className="button"  value={2}   onClick={this.onclickhandeler}>2</button>
                    <button className="button"  value={3}   onClick={this.onclickhandeler}>3</button>
                    <button className="button"  value={'*'} onClick={this.onclickhandeler}>*</button>
              </div>
              <div>
                    <button className="button"  value={'.'} onClick={this.onclickhandeler}>.</button>
                    <button className="button"  value={'0'} onClick={this.onclickhandeler}>0</button>
                    <button className="button"  value={'='} onClick={this.onclickhandeler}>=</button>
                    <button className="button"  value={'/'} onClick={this.onclickhandeler}>/</button>
              </div>
              </div>
            </div>
        )
    }
}
export default Calculator;