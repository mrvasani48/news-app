import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import '../assets/css/news.css'
function News(props) {
  const navigate = useNavigate();
  const [visible, setVisible] = useState(5);
  const [deSearch, setSearch] = useState("apple");

  const loadMore = () => {
    setVisible(visible + 5);
  };
  useEffect(() => {
    fetchNews(deSearch);
  }, []);
  function fetchNews() {
    const url = `https://newsapi.org/v2/everything?q=${deSearch}&sortBy=popularity&apiKey=300cb61a9f1a47fa983c7ebcd9517037`;
    axios
      .get(url)
      .then((response) => {
        props.setNews(response?.data);
      })
      .catch((error) => {
        throw new Error`${error}`();
      });
  }

  return (
    <React.Fragment>
      <div className="container">
        <div className="row">
          <div>
            <div className="d-flex flex-row-reverse mt-3">
            <button
                className="btn btn-outline-success"
                onClick={fetchNews}
                type="submit"
              >
                Search
              </button>
              <input
                className="form-control  me-2"
                type="search"
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search"
                aria-label="Search"
              />
             
            </div>
          </div>
          
          <table className="table ">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Author</th>
                <th scope="col">Title</th>
                <th scope="col">Description</th>
                <th scope="col">PublishedAt</th>
                <th scope="col">Action</th>
              </tr>
            </thead>

            <tbody>
              {props.news?.articles?.slice(0, visible).map((value, index) => {
                return (
                  <tr key={index}>
                    <th scope="row">{index+1}</th>
                    <td>{value.author ? value.author : "Grace Dean)"}</td>
                    <td><b>{value.title}</b></td>
                    <td>{value.description}</td>
                    <td>{value.publishedAt.slice(0, 10)}</td>
                    <td>
                      <button
                        type="submit"
                        className="btn btn-outline-success"
                        onClick={() => {
                          navigate(`/newsmore/${index}`);
                        }}
                      >
                        Explore
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <div className="text-center">
          <button className="btn  btn-outline-success" type="submit" onClick={loadMore}>
            Load More
          </button>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

export default News;
