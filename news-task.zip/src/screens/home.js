import React from 'react'

export default function Home() {
  return (
    <div>
      <h1>Welcome To React Family</h1>
    </div>
  )
}
