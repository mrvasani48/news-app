import React from "react";
import { useParams } from "react-router-dom";
import '../assets/css/newsmore.css'
export default function Newsmore(props) {
  const { id } = useParams();
  const newsData = props?.news?.articles;
  const filterNews = newsData?.filter((value, index) => {
    return index == id;
  });
  const article = filterNews[0];
  return (
    <div className="container">
      <div className="row div-wrapper">    
        <div  className="col-md-6">
        <img src={article.urlToImage} className="card-img-top" alt="..." />
        </div>
         <div className="col-md-6  mt-3">
              <h5 className="card-title title-font">{article.title}</h5>
              <p className="card-text">{article.description}</p>
             
              <p>Author : {article.author ?article.author : "Grace Dean"}</p>
              <p className="text-muted">Published At : {article.publishedAt}</p>
              <a  href={article.url} target="_blank" className="btn btn-outline-success mt-3">
                Read More
              </a>   
        </div>
      </div>
    </div>
  );
}
