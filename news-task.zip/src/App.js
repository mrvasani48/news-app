import React, { useState } from 'react';
import './App.css';
import Navbar from './screens/navbar.js'
import {Routes,Route} from 'react-router-dom'
import Home from './screens/home.js'
import News from './screens/news.js'
import Newsmore from './screens/explorenews'
function App() {
  const [news, setNews] = useState([]);
  return (

   <div>
       <React.Fragment>
         <Navbar />
         <Routes>
            <Route path='/' element={<Home/>}> </Route>
            <Route path='/home' element={<Home/>}> </Route>
            <Route path='/news' element={<News news={news} setNews={setNews}/>}> </Route>
            <Route path="/newsmore/:id" element={<Newsmore news={news} />}></Route>
            <Route path='*' element={<h1>page not found</h1>}> </Route>
          </Routes>   
       </React.Fragment>

   </div>
  );
}

export default App;